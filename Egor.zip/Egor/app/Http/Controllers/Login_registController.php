<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class Login_registController extends Controller
{
    public function index()
    {
        return view('pages.login_regist.index');
    }

    public function create(Request $request)
    {

        dump($request->all());

        User::create([
            'login' => $request -> name,
            'password' => Hash::make($request -> password),
            'email'=>$request -> email,
            'status' => 0
        ]);

        return redirect('/');
    }
}

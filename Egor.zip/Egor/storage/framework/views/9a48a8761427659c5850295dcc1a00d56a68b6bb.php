<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900&subset=latin,latin-ext'>
<link rel="stylesheet" href="login_registr/css/style.css">
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="login_registr/js/index.js"></script>

<?php $__env->startSection('content'); ?>
   <header>
      <div class="logo">
          <a href="/">
              <img src="login_registr/images/logo (header).png" width="260px">
          </a>
      </div>
  </header>
  <div class="materialContainer">
   <form class="box">
      <div class="title">Войти в личный аккаунт</div>
      <div class="input">
         <label for="name">Имя пользователя</label>
         <input type="text" name="login" id="name">
         <span class="spin"></span>
      </div>

      <div class="input">
         <label for="pass">Пароль</label>
         <input type="password" name="password" id="pass">
         <span class="spin"></span>
      </div>

      <div class="button login">
         <button><span>Войти</span> <i class="fa fa-check"></i></button>
      </div>
      <a href="" class="pass-forgot">Забыли пароль?</a>
   </form>

   <form action="/login_regist" method="post" class="overbox">
       <?php echo e(csrf_field()); ?>}
      <div class="material-button alt-2"><span class="shape"></span></div>
      <div class="title">РЕГИСТРАЦИЯ</div>
      <div class="input">
         <label for="regname">Имя пользователя</label>
         <input type="text" name="name" id="regname">
         <span class="spin"></span>
      </div>
      <div class="input">
         <label for="regpass">Пароль</label>
         <input type="password" name="password" id="regpass">
         <span class="spin"></span>
      </div>
      <div class="input">
         <label for="reregpass">Пароль ещё раз</label>
         <input type="password" name="rewpass" id="reregpass">
         <span class="spin"></span>
      </div>
      <div class="button">
         <button type="submit"><span>Далее</span></button>
      </div>
   </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Egor\Desktop\Egor\resources\views/pages/login_regist/index.blade.php ENDPATH**/ ?>
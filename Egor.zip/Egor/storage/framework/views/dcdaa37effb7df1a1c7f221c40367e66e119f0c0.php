<link href="main/css/styles.css" rel="stylesheet">


<?php $__env->startSection('content'); ?>
<header>
        <div class="logo">
            <a href="/">
                <img src="main/images/logo (header).png" width="260px">
            </a>
        </div>
        <div class="bar">
            <div class="searching_bar">
                <input type="search" class="search_bar" name="q" placeholder="Искать...">
            </div>
            <button class="submit_button_bar" type="submit" value=""></button>
        </div>
    </header>
    <div class="left_menu">
        <div class="catalog">
            <div class="exit_wrapper">
                <div class="exit_from_prof">
                    <a href="/login_regist"><input type="button" value="Войти в аккаунт" class="exit"></a>
                </div>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="Feed">
            <div class="sectionTitle">
                <h1>Популярное в Мире</h1>
            </div>
            <section class="posts">
            <div class="post">
                <div class="Prof_and_id">
                    <a href="#"><img class="Post_Prof" src="main/images/Profiles/Dino.png" width="40"></a>
                    <a href="#"><p>Edinooo_Zavrik</p></a>
                    <div class="time_post">
                        <p>Время</p>
                    </div>
                </div>
                <a href="/post">
                    <img class="post_img" src="main/images/Profiles/EdinooHub.png" width="600px">
                </a>
                <hr class="hr_post">
                <p class="Signature">Спросили Пушкина на одном вечере про барыню, с которой он долго разговаривал, как он ее находит, умна ли она?<br>
                    - Не знаю, - отвечал Пушкин очень строго и без желанья поострить, - ведь я с ней говорил по-французски.</p>
                <div class="Like_and_comm">
                    <a href="/login_regist" class="like"><img src="main/images/Icons/like.png" width="50px"></a>
                    <a href="/login_regist" class="comm"><img src="main/images/Icons/comment.png" width="50px"></a>
                </div>
            </div>
                <div class="post">
                    <div class="Prof_and_id">
                        <a href="#"><img class="Post_Prof" src="main/images/Profiles/Dino.png" width="40"></a>
                        <a href="#"><p>Edinooo_Zavrik</p></a>
                        <div class="time_post">
                            <p>Время</p>
                        </div>
                    </div>
                    <a href="/post">
                        <img class="post_img" src="main/images/Profiles/EdinooHub.png" width="600px">
                    </a>
                    <hr class="hr_post">
                    <p class="Signature">Спросили Пушкина на одном вечере про барыню, с которой он долго разговаривал, как он ее находит, умна ли она?<br>
                        - Не знаю, - отвечал Пушкин очень строго и без желанья поострить, - ведь я с ней говорил по-французски.</p>
                    <div class="Like_and_comm">
                        <a href="/login_regist" class="like"><img src="main/images/Icons/like.png" width="50px"></a>
                        <a href="/login_regist" class="comm"><img src="main/images/Icons/comment.png" width="50px"></a>
                    </div>
                </div>
                <div class="post">
                    <div class="Prof_and_id">
                        <a href="#"><img class="Post_Prof" src="main/images/Profiles/Dino.png" width="40"></a>
                        <a href="#"><p>Edinooo_Zavrik</p></a>
                        <div class="time_post">
                            <p>Время</p>
                        </div>
                    </div>
                    <a href="/post">
                        <img class="post_img" src="main/images/Profiles/EdinooHub.png" width="600px">
                    </a>
                    <hr class="hr_post">
                    <p class="Signature">Спросили Пушкина на одном вечере про барыню, с которой он долго разговаривал, как он ее находит, умна ли она?<br>
                        - Не знаю, - отвечал Пушкин очень строго и без желанья поострить, - ведь я с ней говорил по-французски.</p>
                    <div class="Like_and_comm">
                        <a href="/login_regist" class="like"><img src="main/images/Icons/like.png" width="50px"></a>
                        <a href="/login_regist" class="comm"><img src="main/images/Icons/comment.png" width="50px"></a>
                    </div>
                </div>
                <div class="post">
                    <div class="Prof_and_id">
                        <a href="#"><img class="Post_Prof" src="main/images/Profiles/Dino.png" width="40"></a>
                        <a href="#"><p>Edinooo_Zavrik</p></a>
                        <div class="time_post">
                            <p>Время</p>
                        </div>
                    </div>
                    <a href="/post">
                        <img class="post_img" src="main/images/Profiles/EdinooHub.png" width="600px">
                    </a>
                    <hr class="hr_post">
                    <p class="Signature">Спросили Пушкина на одном вечере про барыню, с которой он долго разговаривал, как он ее находит, умна ли она?<br>
                        - Не знаю, - отвечал Пушкин очень строго и без желанья поострить, - ведь я с ней говорил по-французски.</p>
                    <div class="Like_and_comm">
                        <a href="/login_regist" class="like"><img src="main/images/Icons/like.png" width="50px"></a>
                        <a href="/login_regist" class="comm"><img src="main/images/Icons/comment.png" width="50px"></a>
                    </div>
                </div>
            </section>
            <button onclick="topFunction()" id="Button_To_Top" title="Наверх">Наверх</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Egor\Desktop\Egor\resources\views/index.blade.php ENDPATH**/ ?>
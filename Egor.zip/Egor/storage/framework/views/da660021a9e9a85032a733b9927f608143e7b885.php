<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" content="text/css" http-equiv="Content-Type">
    <link href="css/styles.css" rel="stylesheet">
    <script>
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 600 || document.documentElement.scrollTop > 600) {
        document.getElementById("Button_To_Top").style.display = "block";
    } else {
        document.getElementById("Button_To_Top").style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
    </script>
    <title>SocialSim</title>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\Users\Egor\Desktop\Egor\resources\views/layouts/header.blade.php ENDPATH**/ ?>
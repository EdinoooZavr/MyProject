<link href="profil/css/styles.css" rel="stylesheet">

<?php $__env->startSection('content'); ?>
    <header>
        <div class="logo">
            <a href="/prof">
                <img src="profil/images/logo (header).png" width="260px">
            </a>
        </div>
        <div class="bar">
            <div class="searching_bar">
                <input type="search" class="search_bar" name="q" placeholder="Искать...">
            </div>
            <button class="submit_button_bar" type="submit" value=""></button>
            <div class="button_bar">
                <a href="#">
                    <input type="button" value="Поделиться фото и видео" class="share_photo">
                </a>
            </div>
            <div class="icons">
                <a class="bell_img" href="#">
                    <img src="profil/images/icons/Bell.png" width="60px">
                </a>
                <a href="#">
                    <img src="profil/images/icons/Messages.png" width="60px">
                </a>
            </div>
        </div>
    </header>
    <div class="left_menu">
        <div class="prof_pic_and_text">
            <div class="prof_pic">
                <a href="#"><img class="Gomer" src="profil/images/Profiles/GomerProfile.png" width="150px"></a>
            </div>
            <div class="prof_text">
				<p>Гомер Симпсон</p>
                <a href="Gomer_Profile.html">@Gomer_Tupoi</a>
            </div>
        </div>
        <div class="prof_info">
           <table border="1" bordercolor="#f90" rules="cols" frame="void" cellspacing="5" cellpadding="10" class="prof_info_table">
               <tr>
                   <td>264</td>
                   <td>49.7k</td>
                   <td>103</td>
               </tr>
               <tr>
                   <td>Поста</td>
                   <td>Подписчиков</td>
                   <td>Подписок</td>
               </tr>
           </table>
        </div>
        <div class="catalog">
            <ul>
                <li class="news_catalog">
                    <a href="/prof"><img src="profil/images/icons/news.png" width="30px"><p class="text_to_down">Главная</p></a>
                </li>
                <li class="search_catalog">
                    <a href="#"><img src="profil/images/icons/search.png" width="30px"><p class="text_to_down">Поиск</p></a>
                </li>
                <li>
                    <a href="#"><img src="profil/images/icons/Notifications.png" width="35px"><p class="text_to_down">Уведомления</p></a>
                </li>
                <li class="message_catalog">
                    <a href="#"><img src="profil/images/icons/Message.png" width="40px"><p class="text_to_down">Сообщения</p></a>
                </li>
                <li class="friends_catalog">
                    <a href="#"><img src="profil/images/icons/Friends.png" width="40px"><p class="text_to_down">Друзья</p></a>
                </li>
                <li class="community_catalog">
                    <a href="#"><img src="profil/images/icons/community.png" width="35px"><p class="text_to_down">Сообщества</p></a>
                </li>
                <li class="music_catalog">
                    <a href="#"><img src="profil/images/icons/music.png" width="35px"><p class="text_to_down">Музыка</p></a>
                </li>
                <li class="video_catalog">
                    <a href="#"><img src="profil/images/icons/video.png" width="35px"><p class="text_to_down">Видео</p></a>
                </li>
                <li class="photos_catalog">
                    <a href="#"><img src="profil/images/icons/photos.png" width="35px"><p class="text_to_down">Фотографии</p></a>
                </li>
            </ul>
                <hr class="hr_menu">
            <div class="exit">
            <ul>
                <li class="exit_from_prof">
                    <a href="/"><img src="profil/images/icons/exit.png" width="35px"><p class="text_to_down">Выйти из аккаунта</p></a>
                </li>
            </ul>
            </div>
        </div>
    </div>
    <div class="content">
        <div  class="stories">
            <h1>Истории</h1>
                    <div class="story_img">
                        <a href="#"><img src="profil/images/Profiles/Stories/story__add.png" width="70" height="70px"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__1.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__2.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__3.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__4.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__5.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__6.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__7.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__8.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__9.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__10.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__11.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__12.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__13.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__14.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__15.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__16.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__16.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__16.png" width="70"></a>
                        <a href="#"><img src="profil/images/Profiles/Stories/story__16.png" width="70"></a>
                    </div>
        </div>
        <div class="Feed">
            <div class="wrapper">
                <div class="w_box_1"><h1>Рекомендации для вас</h1></div>
                   <div class="w_box_2">
                       <a href="#"><h1 id="w_h1">Сообщества</h1></a>
                       <hr class="w_box_hr">
                       <a href="#"><h1 id="w_h1_2">Люди</h1></a>
                   </div>
                   <div class="w_box_3">
                       <div class="w_content_l">
                           <a href="#"><div class="group_1">
                               <img src="profil/images/groups/1.jpg" width="48" height="48">
                               <div class="name_stat">
                                   <h4>Рифмы и панчи</h4>
                                   <h5>4 446 590 подписчиков</h5>
                               </div>
                           </div></a>
                           <a href="#"><div class="group_1">
                               <img src="profil/images/groups/2.png" width="48" height="48">
                               <div class="name_stat">
                                   <h4>sᴀᴅ ıɴᴊᴇcтıоɴ</h4>
                                   <h5>30 563 подписчика</h5>
                               </div>
                           </div></a>
                           <a href="#"><div class="group_1">
                               <img src="profil/images/groups/3.png" width="48" height="48">
                               <div class="name_stat">
                                   <h4>Police & Military</h4>
                                   <h5>4 246 подписчиков</h5>
                               </div>
                           </div></a>
                           <a href="#"><div class="group_1">
                               <img src="profil/images/groups/4.png" width="48" height="48">
                               <div class="name_stat">
                                   <h4>Компьютерные хитрости</h4>
                                   <h5>158 451 подписчик</h5>
                               </div>
                           </div></a>
                           <a href="#"><div class="group_1">
                               <img src="profil/images/groups/5.png" width="48" height="48">
                               <div class="name_stat">
                                   <h4>4chan</h4>
                                   <h5>369 663 подписчика</h5>
                               </div>
                           </div></a>
                           <a href="#"><div class="group_1">
                               <img src="profil/images/groups/6.png" width="48" height="48">
                               <div class="name_stat">
                                   <h4>Reddit</h4>
                                   <h5>1 265 727 подписчиков</h5>
                               </div>
                           </div></a>
                           <a href="#"><div class="group_1">
                               <img src="profil/images/groups/7.png" width="48" height="48">
                               <div class="name_stat">
                                   <h4>U.S.ArmedForces</h4>
                                   <h5>4 843 подписчика</h5>
                               </div>
                           </div></a>
                           <a href="#"><div class="group_1">
                               <img src="profil/images/groups/8.png" width="48" height="48">
                               <div class="name_stat">
                                   <h4>cartoons.jpg</h4>
                                   <h5>217 097 подписчиков</h5>
                               </div>
                           </div></a>
                           <a href="#"><div class="group_1">
                            <img src="profil/images/groups/9.png" width="48" height="48">
                            <div class="name_stat">
                                <h4>Исторические МЕМуары</h4>
                                <h5>40 993 подписчика</h5>
                            </div>
                        </div></a>
                       </div>
                       <div class="w_content_r">
                           <a href="#"><div class="people_1">
                               <img src="profil/images/People/1.png" width="48" height="48">
                               <div class="name_stat">
                                   <h4>Иван Деушев</h4>
                                   <h5>271 друг</h5>
                               </div>
                           </div></a>
                           <a href="#"><div class="people_1">
                            <img src="profil/images/People/2.png" width="48" height="48">
                            <div class="name_stat">
                                <h4>Ника Прокопьева</h4>
                                <h5>600 друзей</h5>
                            </div>
                        </div></a>
                        <a href="#"><div class="people_1">
                            <img src="profil/images/People/3.png" width="48" height="48">
                            <div class="name_stat">
                                <h4>София Агаева</h4>
                                <h5>2 716 друзей</h5>
                            </div>
                        </div></a>
                        <a href="#"><div class="people_1">
                            <img src="profil/images/People/4.png" width="48" height="48">
                            <div class="name_stat">
                                <h4>Данил Кирюшкин</h4>
                                <h5>943 друга</h5>
                            </div>
                        </div></a>
                        <a href="#"><div class="people_1">
                            <img src="profil/images/People/5.png" width="48" height="48">
                            <div class="name_stat">
                                <h4>Альбина Осипенко</h4>
                                <h5>188 друзей</h5>
                            </div>
                        </div></a>
                        <a href="#"><div class="people_1">
                            <img src="profil/images/People/6.png" width="48" height="48">
                            <div class="name_stat">
                                <h4>Егор Возмищев</h4>
                                <h5>144 друга</h5>
                            </div>
                        </div></a>
                        <a href="#"><div class="people_1">
                            <img src="profil/images/People/7.png" width="48" height="48">
                            <div class="name_stat">
                                <h4>Коля Докукин</h4>
                                <h5>334 друга</h5>
                            </div>
                        </div></a>
                        <a href="#"><div class="people_1">
                            <img src="profil/images/People/8.png" width="48" height="48">
                            <div class="name_stat">
                                <h4>Артём Викторович</h4>
                                <h5>182 друга</h5>
                            </div>
                        </div></a>
                        <a href="#"><div class="people_1">
                            <img src="profil/images/People/9.png" width="48" height="48">
                            <div class="name_stat">
                                <h4>Ксения Кутонова</h4>
                                <h5>170 друзей</h5>
                            </div>
                        </div></a>
                       </div>
                   </div>
            </div>
            <div class="sectionTitle">
                <table class="titles">
                    <tr>
                     <td><a href="/prof"><h1>Новости</h1></a></td>
                     <td class="rightcol"><a href="#"><h1>Популярное</h1></a></td>
                    </tr>
                </table>
            </div>
            <div class="Post_1">
                <div class="Prof_and_id">
                    <a href="#"><img class="Post_Prof" src="profil/images/Profiles/Stories/story__2.png" width="40"></a>
                    <a href="#"><p>Berdnik_Off_nik</p></a>
                    <div class="time_post">
                        <p>Вчера в 20:53</p>
                    </div>
                </div>
                <a href="/post"><img class="Post__1" src="profil/images/Profiles/Feed/Post__1.jpg" width="500px"></a>
                <hr class="hr_post">
                <p class="Signature">Называй меня биг бой, я горилла - я тупой</p>
                <div class="Like_and_comm">
                    <a href="#" class="like"><img src="profil/images/Icons/like.png" width="50px"></a>
                    <a href="#" class="comm"><img src="profil/images/Icons/comment.png" width="50px"></a>
                </div>
            </div>
            <div class="Post_2">
                <div class="Prof_and_id">
                    <a href="#"><img class="Post_Prof" src="profil/images/Profiles/Stories/story__7.png" width="40"></a>
                    <a href="#"><p>Izak_D</p></a>
                    <div class="time_post">
                        <p>28 марта в 16:21</p>
                    </div>
                </div>
                <a href="/post"><img class="Post__2" src="profil/images/Profiles/Feed/Post__2.jpg" width="500px"></a>
                <hr class="hr_post">
                <p class="Signature">Вашей маме зять не нужен?</p>
                <div class="Like_and_comm">
                    <a href="#" class="like"><img src="profil/images/Icons/like.png" width="50px"></a>
                    <a href="#" class="comm"><img src="profil/images/Icons/comment.png" width="50px"></a>
                </div>
            </div>
            <div class="Post_3">
                <div class="Prof_and_id">
                    <a href="#"><img class="Post_Prof" src="profil/images/Profiles/Feed/Prof/313_oooo.plus.png" width="40"></a>
                    <a href="#"><p>bart_simpson</p></a>
                    <div class="time_post">
                        <p>2 сентября в 12:19</p>
                    </div>
                </div>
                <a href="/post"><img class="Post__3" src="profil/images/Profiles/Feed/Post__3.jpg" width="600px"></a>
                <hr class="hr_post">
                <p class="Signature">Мама! Я киберспортсмен в Warface!</p>
                <div class="Like_and_comm">
                    <a href="#" class="like"><img src="profil/images/Icons/like.png" width="50px"></a>
                    <a href="#" class="comm"><img src="profil/images/Icons/comment.png" width="50px"></a>
                </div>
            </div>
            <div class="Post_4">
                <div class="Prof_and_id">
                    <a href="#"><img class="Post_Prof" src="profil/images/Profiles/Feed/Prof/1672_oooo.plus.png" width="40"></a>
                    <a href="#"><p>zloilarin</p></a>
                    <div class="time_post">
                        <p>6 февраля в 11:38</p>
                    </div>
                </div>
                <a href="/post"><img class="Post__4" src="profil/images/Profiles/Feed/Post__4.jpg" width="540px"></a>
                <hr class="hr_post">
                <p class="Signature">Люблю тебя, мразь.</p>
                <div class="Like_and_comm">
                    <a href="#" class="like"><img src="profil/images/Icons/like.png" width="50px"></a>
                    <a href="#" class="comm"><img src="profil/images/Icons/comment.png" width="50px"></a>
                </div>
            </div>
            <button onclick="topFunction()" id="Button_To_Top" title="Наверх">Наверх</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Egor\Desktop\Egor\resources\views/pages/profil/index.blade.php ENDPATH**/ ?>
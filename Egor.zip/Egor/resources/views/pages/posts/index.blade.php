<link href="posts/CSS/styles.css" rel="stylesheet">
@extends('layouts.header')
@section('content')
<header>
    <div class="logo">
        <a href="/prof">
            <img src="posts/images/logo (header).png" width="260px">
        </a>
    </div>
    <div class="bar">
        <div class="searching_bar">
            <input type="search" class="search_bar" name="q" placeholder="Искать...">
        </div>
        <button class="submit_button_bar" type="submit" value=""></button>
        <div class="button_bar">
            <a href="#">
                <input type="button" value="Поделиться фото и видео" class="share_photo">
            </a>
        </div>
        <div class="icons">
            <a class="bell_img" href="#">
                <img src="posts/images/icons/Bell.png" width="60px">
            </a>
            <a href="#">
                <img src="posts/images/icons/Messages.png" width="60px">
            </a>
        </div>
    </div>
</header>
<div class="left_menu">
    <div class="prof_pic_and_text">
        <div class="prof_pic">
            <a href="#"><img class="Gomer" src="posts/images/Profiles/GomerProfile.png" width="150px"></a>
        </div>
        <div class="prof_text">
            <p>Гомер Симпсон</p>
            <a href="Gomer_Profile.html">@Gomer_Tupoi</a>
        </div>
    </div>
    <div class="prof_info">
        <table border="1" bordercolor="#f90" rules="cols" frame="void" cellspacing="5" cellpadding="10" class="prof_info_table">
            <tr>
                <td>264</td>
                <td>49.7k</td>
                <td>103</td>
            </tr>
            <tr>
                <td>Поста</td>
                <td>Подписчиков</td>
                <td>Подписок</td>
            </tr>
        </table>
    </div>
    <div class="catalog">
        <ul>
            <li class="news_catalog">
                <a href="/prof"><img src="posts/images/icons/news.png" width="30px"><p class="text_to_down">Главная</p></a>
            </li>
            <li class="search_catalog">
                <a href="#"><img src="posts/images/icons/search.png" width="30px"><p class="text_to_down">Поиск</p></a>
            </li>
            <li>
                <a href="#"><img src="posts/images/icons/Notifications.png" width="35px"><p class="text_to_down">Уведомления</p></a>
            </li>
            <li class="message_catalog">
                <a href="#"><img src="posts/images/icons/Message.png" width="40px"><p class="text_to_down">Сообщения</p></a>
            </li>
            <li class="friends_catalog">
                <a href="#"><img src="posts/images/icons/Friends.png" width="40px"><p class="text_to_down">Друзья</p></a>
            </li>
            <li class="community_catalog">
                <a href="#"><img src="posts/images/icons/community.png" width="35px"><p class="text_to_down">Сообщества</p></a>
            </li>
            <li class="music_catalog">
                <a href="#"><img src="posts/images/icons/music.png" width="35px"><p class="text_to_down">Музыка</p></a>
            </li>
            <li class="video_catalog">
                <a href="#"><img src="posts/images/icons/video.png" width="35px"><p class="text_to_down">Видео</p></a>
            </li>
            <li class="photos_catalog">
                <a href="#"><img src="posts/images/icons/photos.png" width="35px"><p class="text_to_down">Фотографии</p></a>
            </li>
        </ul>
        <hr class="hr_menu">
        <div class="exit">
            <ul>
                <li class="exit_from_prof">
                    <a href="/"><img src="posts/images/icons/exit.png" width="35px"><p class="text_to_down">Выйти из аккаунта</p></a>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="content">
    <div class="Feed">
        <div class="Post_1">
            <div class="Prof_and_id">
                <a href="#"><img class="Post_Prof" src="posts/images/Profiles/Stories/story__2.png" width="40"></a>
                <a href="#"><p>Berdnik_Off_nik</p></a>
                <div class="time_post">
                    <p>Вчера в 20:53</p>
                </div>
            </div>
            <img class="Post__1" src="posts/images/Profiles/Feed/Post__1.jpg" width="700px">
            <hr class="hr_post">
            <p class="Signature">Называй меня биг бой, я горилла - я тупой</p>
            <div class="input_post">
                <input type="text" class="input_for_post" placeholder="Оставьте ваш комментарий...">
                <div class="comm_wrap">
                    <a href="#" class="comm"><img src="posts/images/Icons/comment_active.png" width="50px"></a>
                </div>
                <div class="like_wrap">
                    <a href="#" class="like"><img src="posts/images/Icons/like.png" width="50px"></a>
                </div>
            </div>
    </div>
    </div>
</div>
@endsection
